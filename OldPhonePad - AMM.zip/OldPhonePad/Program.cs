﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OldPhonePad
{
    internal class Program
    {


        static void Main(string[] args)
        {
            Dictionary<char, string> keypad = new Dictionary<char, string>()
            {
                {'1',"1" },{'2',"ABC"},{'3',"DEF"},{'4',"GHI"},{'5',"JKL"},{'6',"MNO"},{'7',"PQRS"},{'8',"TUV"},{'9',"WXYZ"},{'0',"0"},{'*',"*"}
            };

            Console.WriteLine("Enter input (end with #):");
            string userInput = Console.ReadLine().Trim();

            // Check if input ends with #
            if (userInput.EndsWith("#"))
            {
                userInput = userInput.Substring(0, userInput.Length - 1); // Remove #
                StringBuilder result = new StringBuilder();

                char prevChar = '\0'; // Previous character for backspace

                for (int i = 0; i < userInput.Length; i++)
                {
                    char currentChar = userInput[i];

                    if (currentChar == '*')
                    {
                        // Backspace - delete previous character
                        if (result.Length > 0)
                        {
                            result.Remove(result.Length - 1, 1);
                        }
                    }
                    else if (char.IsDigit(currentChar))
                    {
                        // Check for same digit sequence
                        int count = 1;
                        while (i + 1 < userInput.Length && userInput[i + 1] == currentChar && count < 3)
                        {
                            count++;
                            i++;
                        }
                        result.Append(currentChar, count).Append(',');
                    }
                    else if (currentChar != ' ')
                    {
                        // Invalid character, skip
                        Console.WriteLine("Wrong input format!");
                        return;
                    }

                    prevChar = currentChar;
                }

                // Remove trailing comma
                if (result.Length > 0)
                {
                    result.Length--; // Remove the last character
                }

                // Print the result
                Console.WriteLine("Result:");
                Console.WriteLine(result);

                string inputString = result.ToString();

                string[] sequences = inputString.Split(',');

                // Print the array
                Console.WriteLine("Final Result:");

                string output = "";

                foreach (string sequence in sequences)
                {
                    if(!sequence.Equals(""))
                    {
                        string key = sequence.ToString().Trim().Substring(0, 1);

                        int pressTime = sequence.Length;

                        string keypadValue = keypad[Convert.ToChar(key)];

                        string keypressed = keypressed = keypadValue.Substring(pressTime - 1, 1);

                        output += keypressed;
                    }
                }

                Console.WriteLine(output);
            }
            else
            {
                // Input doesn't end with #
                Console.WriteLine("Wrong input format!");
            }
        }
        
    }
}